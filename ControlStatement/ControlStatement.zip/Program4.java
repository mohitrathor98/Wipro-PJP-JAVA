public class Program4{
	public static void main(String[] args)
	{
		char firstCharacter = 's';
		char secondCharacter = 'e';

		if(firstCharacter > secondCharacter)
		{
			System.out.print(secondCharacter+", "+firstCharacter);
		}
		else
		{
			System.out.print(firstCharacter+","+secondCharacter);		
		}


	}
}