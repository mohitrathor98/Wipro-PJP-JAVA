package Program6;

public class NegativeValuesException extends Exception{
	public NegativeValuesException()
	{
		super("NegativeValuesException occured"); //super call parent class constructor
		
	}

}
