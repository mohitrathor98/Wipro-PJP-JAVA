package Program6;

public class ValuesOutOfRangeException extends Exception{
	public ValuesOutOfRangeException()
	{
		super("ValuesOutOfRangeException occured ");
		
	}

}
