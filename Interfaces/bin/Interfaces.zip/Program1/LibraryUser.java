package Program1;
public interface LibraryUser {
	void registerAccount();
	void requestBook();
}
