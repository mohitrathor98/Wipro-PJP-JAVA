package Program2.live;
import Program2.music.string.*;
import Program2.music.wind.*;
public class Test {
	public static void main(String[] args)
	{
		Veena v=new Veena();
		Sexaphone s=new Sexaphone();
		
		v.play();
		s.play();
	}
}
