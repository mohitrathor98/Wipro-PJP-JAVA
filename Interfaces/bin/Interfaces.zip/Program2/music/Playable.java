package Program2.music;

public interface Playable {
	void play();
}
