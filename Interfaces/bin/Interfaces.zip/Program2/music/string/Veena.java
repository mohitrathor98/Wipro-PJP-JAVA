package Program2.music.string;
import Program2.music.Playable;
public class Veena implements Playable{

	@Override
	public void play() {
		System.out.println("Vena play");
		
	}

}
