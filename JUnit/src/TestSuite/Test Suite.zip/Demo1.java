package TestSuite;

public class Demo1 {
	public String stringConcat(String a,String b)
	{
		return a+b;
	}
}
