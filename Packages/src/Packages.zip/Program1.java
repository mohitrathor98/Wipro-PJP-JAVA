
import test_package.Foundation;

public class Program1{
	public static void main(String[] args)
	{
		Foundation f =new Foundation();
		
		f.var4=2;
		System.out.print(f.var4);
		
	}
}
