import com.wipro.automobile.ship.Compartment;

public class Program2 {
	public static void main(String[] args)
	{
		Compartment compartment=new Compartment(2,3,5);
		
		System.out.print(compartment);
	}
}
